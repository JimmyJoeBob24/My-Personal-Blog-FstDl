put the model into:

"<gamedir>\valve\models\player" folder

end result should be:

"<gamedir>\valve\models\player\jman\jman.mdl"
"<gamedir>\valve\models\player\jman\jman.bmp"

credit vef4